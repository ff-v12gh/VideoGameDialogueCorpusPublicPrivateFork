# Final Fantasy

## Source

The source lists dialogue that is repeated by characters that move around. These are marked with '(r)', and have been removed from the final data. Also, the source contains some comments from the author of the script, which are not canonical.

## Gender coding

"First Officer" has a male sprite, perceived as male in this playthrough:
https://youtu.be/PYDTBvfvjjs?t=546

"Attendant" is seen here, but not clear what the gender is:
https://youtu.be/DuVBhJ5PoRI?t=411

"Person 1" and "Citizen 1" etc. in Lefein are seen here:
https://youtu.be/p3GjWqQSpEk?t=279
There's no clear sign of gender
